"amazing module, please use"

def blue():
    "use this function for blue"
    print("cool blue")
    
def yellow():
    print("bright yellow")
    
def green():
    blue()
    yellow()
    
def red():
    print("scarlet red")